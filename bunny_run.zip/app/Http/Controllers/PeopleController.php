<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Providers\RouteServiceProvider;
use Cookie;
use Hash;
use Session;

class PeopleController extends Controller
{
    public function users(){
        $users = User::orderBy('id','desc')->get();
        return view('people.users',['users'=>$users]);
    }
    public function clients(){
        $users = User::orderBy('id','desc')->get();
        return view('people.clients',['users'=>$users]);
    }
    public function delimen(){
        $users = User::orderBy('id','desc')->get();
        return view('people.delimen',['users'=>$users]);
    }
    public function registration(Request $req)
    {
        $req->validate([
            'user_name' => 'required|min:3',
            'password'=>'required|min:5|same:con_password',
            'con_password' => 'required|min:5',
            'phone' => 'required',
            'state' => 'required'
        ]);
        $data = new User;
        $data->user_name = $req->user_name;
        $data->email = $req->email;
        $data->password = Hash::make($req->password);
        $data->phone = $req->phone;
        $data->address = $req->address;
        $data->township = $req->township;
        $data->member_type= 0;
        $data->state = $req->state;
        $data->user_name = $req->user_name;
        $result = $data->save();
        if($result){
            //return redirect('/success_login');
            return redirect('success_login')->with( 'user_name', $req->user_name);
        }else{
            return back()->with('fail','Something wrong');
        }
    }
}
