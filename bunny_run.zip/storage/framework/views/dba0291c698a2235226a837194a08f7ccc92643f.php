
<?php $__env->startSection('title','Contact Us'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid body_frame">
   <div class="row page_banner">
        <img src="<?php echo e(asset('img/banner_img.jpg')); ?>" alt="">
        <div class="col-10 offset-1 banner_nav">
            <div class="banner_title">Contact Us</div>
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="float:right;">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
            </ol>
            </nav>
        </div>
   </div>
   <div class="container under_construction">
       <img src="<?php echo e(asset('img/uc.gif')); ?>" alt="">
   </div>
</div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bunny_run\resources\views/contact.blade.php ENDPATH**/ ?>