
<?php $__env->startSection('header'); ?>
<h1>Header bar</h1>
<hr>
<?php $__env->stopSection(); ?>;
<?php echo $__env->make('layouts.public_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bunny_run\resources\views/header.blade.php ENDPATH**/ ?>