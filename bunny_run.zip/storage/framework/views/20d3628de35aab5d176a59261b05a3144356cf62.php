
<?php $__env->startSection('title','Branch'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <a href="<?php echo e(url()->previous()); ?>"><i class="fa fa-arrow-circle-left" alt="Back" data-toggle="tooltip"title="Back"></i></a>
        Office
        <small>Branch</small>
      </h1>
     
      <ol class="breadcrumb">
       
        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Office</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="box box-warning">
                <div class="box-body">
                    <div class="row">
                    <div class="col-lg-12">
                    <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                
                                <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                
                                <?php echo e(Session::get('fail')); ?>

                            </div>
                            <?php endif; ?> 
                    </div>
                    <div class="col-lg-12">
                       <h4>Branch 
                       <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#modal-default">
                        <i class="fa fa-plus"></i> New
                      </button>
                        </h4>
                     
                      <table class="table table-bordered table-striped data_list" id="">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Branch Name</th>
                            <th>Address</th>
                            <th>Township/City</th>
                            <th>State</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                         <tbody>
                            <?php ($count=1); ?>
                            <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($name->branch_name); ?></td>
                                    <td><?php echo e($name->address); ?></td>
                                    <td><?php echo e($name->township); ?></td>
                                    <td>
                                      <?php 
                                        $state_id = DB::table('states')->where('id',$name->state_id)->first();
                                        echo $state_id->state_name;
                                      ?>
                                    </td>
                                    <td>
                                    <a href="#" data-toggle="modal" data-target="#modal-edti_<?php echo e($name->id); ?>">
                                        <button type="button" class="btn btn-xs btn-info" data-toggle="tooltip"title="Edit"><i class="fa fa-edit"></i></button>
                                    </a>
                                    <a href="#delModal" id="<?php echo e($name->id); ?>" class="delete">
                                        <button class="btn btn-xs btn-danger" data-toggle="tooltip"title="Delete"><i class="fa fa-times"></i></button>
                                    </a>
      <div class="modal fade" id="modal-edti_<?php echo e($name->id); ?>">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Create New Branch</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?php echo e(url('office/update_branch')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="">Branch Name</label>
                  <input type="hidden" name="id" value="<?php echo e($name->id); ?>">
                  <input type="text" class="form-control" name="branch_name" value="<?php echo e($name->branch_name); ?>" required>
                </div>
                <div class="form-group">
                  <label for="">Address</label>
                  <input type="text" class="form-control" name="address" value="<?php echo e($name->address); ?>" required>
                </div>
                <div class="form-group">
                  <label for="">Township/City</label>
                  <input type="text" class="form-control" name="township" value="<?php echo e($name->township); ?>" required>
                </div>
                <div class="form-group">
                  <label for="">State</label>
                  <select name="state" id="" class="form-control" required>
                      <option value=""> Select State</option>
                      <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>" <?php echo e(( $value->id == $name->state_id) ? 'selected' : ''); ?> ><?php echo e($value->state_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              
              </div>
              <!-- /.box-body -->
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save <i class="fa fa-check"></i></button>
                <button type="reset" class="btn btn-warning">Reset <i class="fa fa-times"></i></button>
              </div>
          </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                      </table>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Create New Branch</h4>
              </div>
              <div class="modal-body">
              <form role="form" action="<?php echo e(url('office/create_branch')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="">Branch Name</label>
                  <input type="text" class="form-control" name="branch_name" placeholder="Enter Branch Name" required>
                </div>
                <div class="form-group">
                  <label for="">Address</label>
                  <input type="text" class="form-control" name="address" placeholder="Address" required>
                </div>
                <div class="form-group">
                  <label for="">Township/City</label>
                  <input type="text" class="form-control" name="township" placeholder="Township/City" required>
                </div>
                <div class="form-group">
                  <label for="">State</label>
                  <select name="state" id="" class="form-control" required>
                      <option value=""> Select State</option>
                      <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              
              </div>
              <!-- /.box-body -->
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save <i class="fa fa-check"></i></button>
                <button type="reset" class="btn btn-warning">Reset <i class="fa fa-times"></i></button>
              </div>
          </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
        <div class="modal modal-danger fade" id="delModal">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Delete Confirmation</h4>
              </div>
              <div class="modal-body">
                <p>Are you sure you wnat to DELETE Branch!&hellip;</p>
              </div>
              <div class="modal-footer del_foot" id="del_foot">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline delete_confrim">Confirm Delete</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal end -->
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('admin/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        var id;
      $('.data_list').on('click', '.delete', function(e) {
        
        e.preventDefault();
        id = e.currentTarget.id;
        //alert(id);
        $('#delModal').modal('show');
        return false;
      });
      
      $('#del_foot').on('click', '.delete_confrim', function(e){
          window.location = 'delete_branch/' + id;
          //alert(id);
      });
    });
  </script>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bunny_run\resources\views/admin/branch.blade.php ENDPATH**/ ?>