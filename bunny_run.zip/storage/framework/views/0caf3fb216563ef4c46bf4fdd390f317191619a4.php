
<?php $__env->startSection('title','Zone'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <a href="<?php echo e(url()->previous()); ?>"><i class="fa fa-arrow-circle-left" alt="Back" data-toggle="tooltip"title="Back"></i></a>
        System Setup
        <small>Zone</small>
      </h1>
     
      <ol class="breadcrumb">
       
        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Zone</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="box box-warning">
                <div class="box-body">
                <div class="row">
                    <div class="col-lg-12">
                    <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                
                                <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                
                                <?php echo e(Session::get('fail')); ?>

                            </div>
                            <?php endif; ?> 
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8">
                    <h4>Zone List</h4>
                    <table class="table table-bordered table-striped data_list" id="example1">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Zone Name</th>
                            <th>State</th>
                            <th>Township</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                         <tbody>
                         <?php ($count=1); ?>
                         <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($zone->zone_name); ?></td>
                                <td>
                                  <?php
                                      $data = DB::table('states')->where('id', $zone->state_id)->first();
                                      echo $data->state_name;
                                  ?>
                                </td>
                                <td>
                                  <ul style="padding-left:7px; margin-left:0;">
                                    <?php
                                      $zone_detail = DB::table('zone_detail')->where('zone_id', $zone->id)->get();
                                      foreach($zone_detail as $town){
                                    ?>
                                    <li style="margin-bottom:2px; padding:5px; background:#eee;">
                                      <?php echo e($town->township_name); ?>

                                      <button class="btn btn-xs btn-warning" style="float:right;" data-toggle="tooltip"title="Del Township"><i class="fa fa-times"></i></button>
                                   </li>
                                    <?php } ?>
                                  </ul>
                                </td>
                                <td style="width:50px;">
                                <button class="btn btn-sm btn-danger" style="float:right;" data-toggle="tooltip"title="Del Zone"><i class="fa fa-trash"></i></button>
                              </td>
                              </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                    <div class="col-lg-4">
                        <h4>Create New Zone</h4>
                        <form role="form" action="<?php echo e(url('system/create_zone')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Zone Name</label>
                                <input type="text" class="form-control" name="zone_name" placeholder="Enter Zone Name" required>
                                <span class="text-danger"><?php $__errorArgs = ['zone_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                            <div class="form-group">
                                <label for="">State</label>
                                <select name="state" id="state" class="form-control" required>
                                    <option value="">Select State</option>
                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->state_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger"><?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                            <div id="townshiplist" class="form-group">
                            <h4>Choose Township</h4>
                            </div>
                            <span class="text-danger"><?php $__errorArgs = ['towhship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            <divclass="form-group">
                                <button type="submit" class="btn btn-success">Create <i class="fa fa-check"></i></button>
                                <button type="reset" class="btn btn-warning">Cancel <i class="fa fa-times"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    </section>
    <!-- /.content -->
  </div>
  
        <div class="modal modal-danger fade" id="delModal">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Delete Confirmation</h4>
              </div>
              <div class="modal-body">
                <p>Are you sure you wnat to DELETE Branch!&hellip;</p>
              </div>
              <div class="modal-footer del_foot" id="del_foot">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline delete_confrim">Confirm Delete</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal end -->
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('admin/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        var id;
      $('.data_list').on('click', '.delete', function(e) {
        
        e.preventDefault();
        id = e.currentTarget.id;
        //alert(id);
        $('#delModal').modal('show');
        return false;
      });
      
      $('#del_foot').on('click', '.delete_confrim', function(e){
          window.location = 'delete_branch/' + id;
          //alert(id);
      });
      //get township code
      $("#state").change(function(){
      var id = $(this).val();
      var div=$(this).parent();
      var op=" ";
            $.ajax
            ({
                type: "get",
                url: "/system/gettownship",
                //url:'<?php echo URL::to('gettownship'); ?>',
                dataType: 'json',
                data: {'id':id},
                success: function (data) {
                    op+='<h4>Choose Township</h4>';
                            for(var i=0;i<data.length;i++){
                            op+='<input type="checkbox" value="'+data[i].township_name+'" name="township[]" style="margin-left:10px;"> '+data[i].township_name+ '<br>';
                            }
                        document.getElementById('townshiplist').innerHTML=op;
                }
            })
        });
    });
  </script>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bunny_run\resources\views/admin/zone.blade.php ENDPATH**/ ?>