
<?php $__env->startSection('title','Employee Detail'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <a href="<?php echo e(url()->previous()); ?>"><i class="fa fa-arrow-circle-left" alt="Back" data-toggle="tooltip"title="Back"></i></a>
        Office
        <small>Employee Detail</small>
      </h1>
     
      <ol class="breadcrumb">
       
        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Employee Detail</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="box box-warning">
                <div class="box-body">
                    <div class="row">
                    <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <h4><i class="icon fa fa-check"></i> Finished!</h4>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                                <?php echo e(Session::get('fail')); ?>

                            </div>
                            <?php endif; ?>
                    <div class="col-lg-7">
                      <!-- <div class="col-lg-3 col-lg-offset-9" style="padding-right:0; padding-bottom:10px;">
                        <input type="text" name="search" class="form-control search" placeholder="Search:: keyword">
                      </div> -->
                      <div class="ajaxlist" id="ajaxlist">
                      <h3 class="text-danger">Personal Information</h3>
                       <table class="table table-bordered table-striped data_list">
                          <tr>
                            <th style="">Name</th>
                            <th>:</th>
                            <td><?php echo e($employee->empname); ?></td>
                          </tr>
                          <tr>
                            <th style="">Email</th>
                            <th>:</th>
                            <td><?php echo e($employee->email); ?></td>
                          </tr>
                          <tr>
                            <th style="">Phone</th>
                            <th>:</th>
                            <td><?php echo e($employee->phone); ?></td>
                          </tr>
                          <tr>
                            <th style="">Address</th>
                            <th>:</th>
                            <td><?php echo e($employee->address); ?><br> <?php echo e($employee->township); ?></td>
                          </tr>
                          <tr>
                            <th style="">State/Region</th>
                            <th>:</th>
                            <td>
                            <?php
                                  $data = DB::table('states')->where('id', $employee->state_id)->first();
                                  echo $data->state_name;
                              ?>
                            </td>
                          </tr>
                        </table>
                      </div>
                    </div>
                    <div class="col-lg-5">
                      <div>
                      <h3 class="text-primary">Employee Information</h3>
                       <table class="table table-bordered table-striped data_list">
                          <tr>
                            <th style="">Join Date</th>
                            <th>:</th>
                            <td><?php echo e($employee->join_date); ?> <span class="text-success" style="float:right;">
                            <?php
                            use Carbon\Carbon;
                            $myDate = $employee->join_date;
                            $result = Carbon::createFromFormat('Y-m-d', $myDate)->diffForHumans();
                            echo $result;
                            ?>
                            </span>
                            </td>
                          </tr>
                          <tr>
                            <th style="">Position</th>
                            <th>:</th>
                            <td><?php echo e($employee->position); ?></td>
                          </tr>
                          <tr>
                            <th style="">Department</th>
                            <th>:</th>
                            <td><?php echo e($employee->department); ?></td>
                          </tr>
                          <tr>
                            <th style="">Brand </th>
                            <th>:</th>
                            <td>
                            <?php
                                  $branch = DB::table('branchs')->where('id', $employee->branch_id)->first();
                                  echo $branch->branch_name;
                              ?>
                            </td>
                          </tr>
                          <tr>
                            <th style="">State/Region</th>
                            <th>:</th>
                            <td>
                            <?php
                                  $data = DB::table('states')->where('id', $employee->state_id)->first();
                                  echo $data->state_name;
                              ?>
                            </td>
                          </tr>
                          <tr>
                            <th style="">Admin Remark</th>
                            <th>:</th>
                            <td>
                            <?php echo e($employee->remark); ?>

                            </td>
                          </tr>
                        </table>
                      </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bunny_run\resources\views/admin/emp_detail.blade.php ENDPATH**/ ?>